// Ian Reyes
// CPSC 120-06
// 2022-11-16
// ireyes4341@csu.fullerton.edu
// @IanReyes44
//
// Lab 11-02
// Partners: @austinnguyenlee
//
// This program plays a game of HiLo
//

#include "hilo.h"

#include "rng.h"

GameState::GameState(int secret) : secret_(secret) {}

int GameState::Secret() const {
return secret_;
}

int GameState::GuessesLeft() const {
  
  return guesses_left_;
}

bool GameState::GuessCorrect(int guess) const {
  if (guess == secret_) {
    return true;
  }
  return false;
}

bool GameState::GuessTooBig(int guess) const {
  if (guess > secret_) {
    return true;
  }
  return false; 
}

bool GameState::GuessTooSmall(int guess) const {
  if (guess < secret_) {
    return true;
  }
  return false;
}

void GameState::CountGuess() {
  guesses_left_ = guesses_left_ - 1;
}

bool GameState::GameOver() const {
  if (guesses_left_ == 0) {
    return true;
  }
  
  return false;
}

int RandomSecretNumber() {
  // TODO: write statements to implement this function, and delete this comment
  // Hint: first seed the random number generator
  // then generate a random number between 1 and 10
  // finally return that random number
  return 0; // TODO: replace this return statement with one that actually works
}
